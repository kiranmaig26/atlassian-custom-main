package jira.conditions

return !(issue.priority.name in ["Низкий"])

